    s=tf('s');
    gol=10000/(20*s^3+1009*s^2+451*s+50);
    f=0.01/(s+1);
    ki=0.1;
    a=(ki+(1-ki^2)^0.5*s)/s;
    
    go=gol*f*a;
%     gc=10000*(s+1)/(20*s^4+1029*s^3+1460*s^2+501*s+150);
%     rlocus(gol);
     rlocus(go);    
%     bode(go);
%     grid on

% a=-0:0.01:10;
% b=a;
% for i=1:1001
% b(i)=atan(a(i)/3)+pi/2+atan(a(i));
% end
% plot(b);
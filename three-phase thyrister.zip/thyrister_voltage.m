h=0.1;
wt=-30:h:390;
wt1=wt*2*pi/360;
u=60;
ua=sin(wt1);
ub=sin(wt1-2*pi/3);
uc=sin(wt1+2*pi/3);
uab=ua-ub;
ubc=ub-uc;
uca=uc-ua;
ul=[uca(1:120/h),zeros(1,120/h),-uab(210/h:330/h),uca(1:60/h)];


figure
plot(wt,-ul,'*')
hold on
plot(wt,uab)
hold on
plot(wt,ubc)
hold on
plot(wt,uca)
hold off
grid on
legend(["U_thy" "u_a_b" "u_b_c" "u_c_a"])
ylabel("��Դ�С")
xlabel("wt���㣩")
title("V-thyristor")
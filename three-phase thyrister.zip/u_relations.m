h=0.1;
wt=h:h:180;
wt1=wt*2*pi/360;
u=zeros(1,180/h);

for i=1:180/h
u(i)=fu(wt1(i),0.5);
end
figure
plot(wt,u)
legend(["u" ])
ylabel("u(��)")
xlabel("a���㣩")
title("u-a")




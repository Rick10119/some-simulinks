h=0.1;
wt=-30:h:390;
wt1=wt*2*pi/360;
ua=sin(wt1);
ub=sin(wt1-2*pi/3);
uc=sin(wt1+2*pi/3);
a=90;u=30;
us=0;
for i=1:420/h+1
    if(i<(30+a)/h)
        us(i)=uc(i);end
    if(i<(a-60)/h)
        us(i)=(uc(i)+ub(i))/2;end
    if(i>(30+a)/h&&i<(30+a+u)/h)%u
        us(i)=(ua(i)+uc(i))/2;end
    if(i>(30+a+u)/h&&i<(30+a+120)/h)
        us(i)=ua(i);end
    if(i>(30+a+120)/h&&i<(30+a+120+u)/h)%u
        us(i)=(ub(i)+ua(i))/2;end
     if(i>(30+a+120+u)/h&&i<(30+a+240)/h)
        us(i)=ub(i);end
    if(i>(30+a+240)/h&&i<(30+a+240+u)/h)%u
        us(i)=(uc(i)+ub(i))/2;end
    if(i>(30+a+240+u)/h)
        us(i)=uc(i);end
end


ul=us;

figure
plot(wt,ul,'*')
hold on
plot(wt,ua)
hold on
plot(wt,ub)
hold on
plot(wt,uc)
hold off
grid on
ylabel("��Դ�С")
xlabel("wt���㣩")
title("V_p")
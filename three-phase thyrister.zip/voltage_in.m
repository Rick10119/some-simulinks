wt=-60:0.1:420;
wt1=wt*2*pi/360;
ua=sin(wt1);
ub=sin(wt1-2*pi/3);
uc=sin(wt1+2*pi/3);


figure

plot(wt,ua)
hold on

plot(wt,ub)
hold on
plot(wt,uc)
hold off
grid on
legend(["u_a" "u_b" "u_c"])
ylabel("��Դ�С")
xlabel("wt���㣩")
title("U-AC supply")
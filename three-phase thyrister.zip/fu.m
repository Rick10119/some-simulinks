function u=fu(a,c)
u=acos(cos(a)-c)-a;
u=u*180/pi;
end

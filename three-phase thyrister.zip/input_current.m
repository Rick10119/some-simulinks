wt=-30:0.1:390;
wt1=wt*2*pi/360;
ua=sin(wt1);
ub=sin(wt1-2*pi/3);
uc=sin(wt1+2*pi/3);
ia=[-ones(1,120/h),zeros(1,60/h),ones(1,120/h),zeros(1,60/h),-ones(1,60/h+1)];

figure

plot(wt,ua)
hold on
plot(wt,ia)
hold off
grid on
legend(["u_a" "i_a"])
ylabel("��Դ�С")
xlabel("wt���㣩")
title("I-AC supply")
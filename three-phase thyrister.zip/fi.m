function i=fi(a,c,wt)
i=c*(cos(a)-cos(wt+a));
if(i>1)
    i=1;
end
if(wt>2*pi/3)
    i=1-c*(cos(a)-cos(wt+a-2*pi/3));
end
if (i<0)
    i=0;
end
end
h=0.1;
wt=h:h:180;
wt1=wt*2*pi/360;
u=zeros(1,180/h);

a=0;c=2;
for i=1:180/h
u(i)=fi(a,c,wt1(i));
end
figure
plot(wt,u)
legend(["u" ])
ylabel("i(/I_d)")
xlabel("wt���㣩")
title("i-wt(a=0��,c=2)")

s=tf('s');
m=10/((s+1)^2*(s^2+8*s+16));
rlocus(m);